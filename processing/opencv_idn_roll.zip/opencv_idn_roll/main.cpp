#include <stdio.h>
#include <opencv2/core/core.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/imgproc/imgproc.hpp>

using namespace cv;
using namespace std;

Mat src;
Mat src_gray;
Mat th_output;

int thresh = 100;
int max_thresh = 255;
int canny = 100;
int max_canny = 255;
RNG rng(12345);

char *source_window = "Source";

/// Function header
void canny_callback(int, void* );
void thresh_callback(int, void* );

/** @function main */
int main( int argc, char** argv )
{
  /// Load source image and convert it to gray
  src = imread( "c:\\Users\\bernau84\\Pictures\\role2_detail_retus_1_2.bmp", 1 );

  /// Convert image to gray and blur it
  cv::cvtColor( src, src_gray, CV_BGR2GRAY );
//  blur( src_gray, src_gray, Size(3,3) );

  /// Create Window

  namedWindow( source_window, CV_WINDOW_AUTOSIZE );
  imshow( source_window, src );

  createTrackbar( " Thresh:", source_window, &thresh, max_thresh, thresh_callback );
  thresh_callback( 0, 0 );

  createTrackbar( " Canny thresh:", source_window, &canny, max_canny, canny_callback );
  canny_callback( 0, 0 );

  waitKey(0);
  return(0);
}

/** @function thresh_callback */
void canny_callback(int, void* )
{
    Mat canny_output;
    Mat blur_output;
    vector<vector<Point> > contours;
    vector<Vec4i> hierarchy;

    blur( th_output, blur_output, Size(3,3) );

    /// Detect edges using canny
    Canny( blur_output /*src_gray*/, canny_output, canny, canny*2, 5 );
    /// Find contours
    findContours( th_output /*canny_output*/, contours, hierarchy, CV_RETR_TREE, CV_CHAIN_APPROX_SIMPLE, Point(0, 0) );

    /// Draw contours
    Mat drawing = Mat::zeros( th_output.size(), CV_8UC3 );
    vector<RotatedRect> minRect( contours.size() );

    for( int i = 0; i< contours.size(); i++ )
       {
         if(contourArea(contours[i]) > 100){

             Scalar color = Scalar( rng.uniform(0, 255), rng.uniform(0,255), rng.uniform(0,255) );
             drawContours( drawing, contours, i, color, 2, 8, hierarchy, 0, Point() );

             minRect[0] = minAreaRect( Mat(contours[i]) );
         }
       }

    Mat contours_mat;
    cv::cvtColor(drawing, contours_mat, CV_BGR2GRAY );

//    vector<Vec4i> lines;
//    HoughLinesP( contours_mat, lines, 1, CV_PI/180, 80, 30, 10 );
//    for( size_t i = 0; i < lines.size(); i++ )
//    {
//        line( drawing, Point(lines[i][0], lines[i][1]),
//            Point(lines[i][2], lines[i][3]), Scalar(0,0,255), 3, 8 );
//    }

    Point2f rect_points[4]; minRect[0].points( rect_points );
    Scalar color_line = Scalar( rng.uniform(0, 255), rng.uniform(0,255), rng.uniform(0,255) );
    for( int j = 0; j < 4; j++ )
       line( drawing, rect_points[j], rect_points[(j+1)%4], color_line, 1, 8 );

    /// Show in a window
    namedWindow( "Contours", CV_WINDOW_AUTOSIZE );
    imshow( "Contours", drawing );
}

void thresh_callback(int, void* )
{
    threshold( src_gray, th_output, thresh, 255, THRESH_BINARY);
    namedWindow( "Thr", CV_WINDOW_AUTOSIZE );
    imshow( "Thr", th_output );
}

