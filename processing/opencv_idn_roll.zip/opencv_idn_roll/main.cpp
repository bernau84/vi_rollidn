#include <stdio.h>
#include <opencv2/core/core.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/imgproc/imgproc.hpp>
#include <QDebug>

using namespace cv;
using namespace std;

Mat src;
Mat src_gray;
Mat th_output;

int thresh = 80;
int max_thresh = 255;
int canny = 100;
int max_canny = 255;
RNG rng(12345);

char *source_window = "Source";

/// Function header
void canny_callback(int, void* );
void thresh_callback(int, void* );

/** @function main */
int main( int argc, char** argv )
{
  /// Load source image and convert it to gray
  src = imread( "c:\\Users\\bernau84\\Pictures\\basler_newlenz_roll_turnov\\role2_detail_retus_1_2.bmp", 1 );

  /// Convert image to gray and blur it
  cv::cvtColor( src, src_gray, CV_BGR2GRAY );
//  blur( src_gray, src_gray, Size(3,3) );

  /// Create Window

  namedWindow( source_window, CV_WINDOW_AUTOSIZE );
  imshow( source_window, src );

  createTrackbar( " Thresh:", source_window, &thresh, max_thresh, thresh_callback );
  thresh_callback( 0, 0 );

  createTrackbar( " Canny thresh:", source_window, &canny, max_canny, canny_callback );
  canny_callback( 0, 0 );

  waitKey(0);
  return(0);
}

/** @function thresh_callback */
void canny_callback(int, void* )
{
    Mat canny_output;
    Mat blur_output;
    vector<vector<Point> > contours;
    vector<Vec4i> hierarchy;

    blur( th_output, blur_output, Size(3,3) );

    /// Detect edges using canny
    Canny( blur_output /*src_gray*/, canny_output, canny, canny*2, 5 );
    /// Find contours
    findContours( th_output /*canny_output*/, contours, hierarchy, CV_RETR_TREE, CV_CHAIN_APPROX_SIMPLE, Point(0, 0) );

    /// Draw contours
    Mat drawing = Mat::zeros( th_output.size(), CV_8UC3 );
    vector<RotatedRect> minRect( contours.size() );
    for( int i = 0; i< contours.size(); i++ )
       {
         if(contourArea(contours[i]) > 100){

             Scalar color = Scalar( rng.uniform(0, 255), rng.uniform(0,255), rng.uniform(0,255) );
             drawContours( drawing, contours, i, color, 1, 8, hierarchy, 0, Point() );

             minRect[0] = minAreaRect( Mat(contours[i]) );
         }
       }

    Mat contours_mat;
    cv::cvtColor(drawing, contours_mat, CV_BGR2GRAY );

    Point2f rect_points[4]; minRect[0].points( rect_points );
    Scalar color_line = Scalar( rng.uniform(0, 255), rng.uniform(0,255), rng.uniform(0,255) );
    for( int j = 0; j < 4; j++ )
       line( drawing, rect_points[j], rect_points[(j+1)%4], color_line, 1, 8 );

    /// Show in a window
    namedWindow( "Contours", CV_WINDOW_AUTOSIZE );
    imshow( "Contours", drawing );

    // matrices we'll use
    Mat M, rotated, cropped;
    // get angle and size from the bounding box
    float angle = minRect[0].angle;
    Size rect_size = minRect[0].size;
    // thanks to http://felix.abecassis.me/2011/10/opencv-rotation-deskewing/
    if (angle < -45.) {
        angle += 90.0;
        swap(rect_size.width, rect_size.height);
    }
    // get the rotation matrix
    M = getRotationMatrix2D(minRect[0].center, angle, 1.0);
    // perform the affine transformation
    warpAffine(contours_mat, rotated, M, src.size(), INTER_NEAREST);
    // crop the resulting image
    getRectSubPix(rotated, rect_size, minRect[0].center, cropped);

    qDebug() << "rows" << QString::number(cropped.rows);
    qDebug() << "clms" << QString::number(cropped.cols);

    cv::Rect myROI1(cropped.rows/3, 0, cropped.cols - 2*cropped.rows/3, cropped.rows/2);
    Mat cropped_sel1 = cropped(myROI1);

    vector<Point> locations1; Vec4f line1;   // output, locations of non-zero pixels; vx, vy, x0, y0
    cv::findNonZero(cropped_sel1, locations1);
    cv::fitLine(locations1, line1, CV_DIST_L2, 0, 0.01, 0.01);

    qDebug() << "line1" << QString::number(line1[0])
            << QString::number(line1[1]) << QString::number(line1[2]) << QString::number(line1[3]);

    cv::line(cropped_sel1,
             Point(0/*line1[2]*/, line1[3]),
             Point(line1[2]+line1[0]*cropped_sel1.cols, line1[3]+line1[1]*cropped_sel1.rows),
             Scalar(255, 255 ,255),
             1, 8);

    cv::Rect myROI2(cropped.rows/3, cropped.rows/2-1, cropped.cols - 2*cropped.rows/3, cropped.rows/2);
    Mat cropped_sel2 = cropped(myROI2);

    vector<Point> locations2; Vec4f line2;  // output, locations of non-zero pixels
    cv::findNonZero(cropped_sel2, locations2);
    cv::fitLine(locations2, line2, CV_DIST_L2, 0, 0.01, 0.01);

    qDebug() << "line2" << QString::number(line2[0])
            << QString::number(line2[1]) << QString::number(line2[2]) << QString::number(line2[3]);

    cv::line(cropped_sel2,
             Point(0/*line1[2]*/, line2[3]),
             Point(line2[2]+line2[0]*cropped_sel1.cols, line2[3]+line2[1]*cropped_sel2.rows),
             Scalar(255, 255 ,255),
             1, 8);

    float width = line2[3] - line1[3] + cropped.rows/2;
    qDebug() << "Width:" << QString::number(width);

    cv::Rect myROI3(0, line1[3], cropped.cols/2, width);
    Mat cropped_sel3 = cropped(myROI3);
    vector<Point> locations3; Vec4f line3;   // output, locations of non-zero pixels; vx, vy, x0, y0

    for(int y = 0; y < cropped_sel3.rows; y++)
        for(int x = 0; x < cropped_sel3.cols; x++)
            if(cropped_sel3.at<uchar>(Point(x, y))){

                locations3.push_back(Point(x, y));
                break;
            }

    Mat trans1sel = Mat::zeros(cropped_sel3.size(), CV_8UC1);
    vector<Point> locations3t;
    for(int i=0; i<locations3.size(); i++){

        float y_deoffs = locations3[i].y - width/2; //now in range +/- width/2
        Point p(locations3[i].x,
                width * sqrt(1 - pow(y_deoffs/(width/2), 2)));  //in picture coords

        locations3t.push_back(p);

        cv::line(trans1sel, p, p, Scalar(255, 255, 255), 2, 8);
    }

    cv::fitLine(locations3t, line3, CV_DIST_L2, 0, 0.01, 0.01);
    qDebug() << "line3" << QString::number(line3[0])
            << QString::number(line3[1]) << QString::number(line3[2]) << QString::number(line3[3]);

    cv::line(trans1sel,
             Point(line3[2]-line3[0]*200, line3[3]-line3[1]*200),
             Point(line3[2]+line3[0]*200, line3[3]+line3[1]*200),
             Scalar(128, 128 ,128),
             3, CV_AA);

    imshow( "Trans1Sel", trans1sel);

    float left_corr = fabs((line3[3] / line3[1]) * line3[0]) + line3[2];
    qDebug() << "Correction-Left:" << QString::number(left_corr);

    cv::line(cropped,
             Point(fabs(left_corr), 0),
             Point(fabs(left_corr), drawing.rows),
             Scalar(128, 0,128),
             1, CV_AA);

    cv::Rect myROI4(cropped.cols/2, line1[3], cropped.cols/2, width);
    Mat cropped_sel4 = cropped(myROI4);
    vector<Point> locations4; Vec4f line4;  // output, locations of non-zero pixels

    for(int y = 0; y < cropped_sel4.rows; y++)
        for(int x = 0; x < cropped_sel4.cols; x++)
            if(cropped_sel4.at<uchar>(Point(cropped_sel4.cols - x - 1, y))){

                locations4.push_back(Point(x, y));
                break;
            }

    Mat trans2sel = Mat::zeros(cropped_sel4.size(), CV_8UC1);
    vector<Point> locations4t;
    for(int i=0; i<locations4.size(); i++){

        float y_deoffs = locations4[i].y - width/2; //now in range +/- width/2
        Point p(locations4[i].x,
                width * sqrt(1 - pow(y_deoffs/(width/2), 2)));  //in picture coords

        locations4t.push_back(p);

        cv::line(trans2sel, p, p, Scalar(255, 255, 255), 2, 8);
    }

    cv::fitLine(locations4t, line4, CV_DIST_L2, 0, 0.01, 0.01);
    qDebug() << "line4" << QString::number(line4[0])
            << QString::number(line4[1]) << QString::number(line4[2]) << QString::number(line4[3]);

    cv::line(trans2sel,
             Point(line4[2]-line4[0]*200, line4[3]-line4[1]*200),
             Point(line4[2]+line4[0]*200, line4[3]+line4[1]*200),
             Scalar(128, 128 ,128),
             3, CV_AA);

    imshow( "Trans2Sel", trans2sel);

    float right_corr = fabs((line4[3] / line4[1]) * line4[0]) + line4[2];
    qDebug() << "Correction-Right:" << QString::number(right_corr);

    cv::line(cropped,
             Point(cropped.cols - fabs(right_corr), 0),
             Point(cropped.cols - fabs(right_corr), drawing.rows),
             Scalar(128, 0,128),
             2, CV_AA);

    cv::ellipse(cropped, Point(left_corr, line1[3] + width/2), Size(left_corr, width/2), 0.0, 0.0, 360, Scalar(64, 64, 64), 2, 4);
    cv::ellipse(cropped, Point(cropped.cols - right_corr, line1[3] + width/2), Size(right_corr, width/2), 0.0, 0.0, 360, Scalar(64, 64, 64), 2, 4);

    float height = cropped.cols - left_corr - right_corr;
    qDebug() << "Height:" << QString::number(height);

    imshow( "Cropped", cropped );
}

void thresh_callback(int, void* )
{
    threshold( src_gray, th_output, thresh, 255, THRESH_BINARY);
    //namedWindow( "Thr", CV_WINDOW_AUTOSIZE );
    //imshow( "Thr", th_output );
}

